﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=.;Database=BookShop;TrustServerCertificate=True;User Id=sa;Password=AsDf23SQLServer";
    }
}
