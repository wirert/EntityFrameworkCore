﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=.;Database=ProductShop;TrustServerCertificate=True;User Id=sa;Password=AsDf23SQLServer";
    }
}
