﻿namespace MusicHub.Data.Common;

public static class DBConfig
{
    public const string ConnectionString = @"Server=.;Database=MusicHub;TrustServerCertificate=True;User Id=sa;Password=AsDf23SQLServer;Encrypt=False";
}