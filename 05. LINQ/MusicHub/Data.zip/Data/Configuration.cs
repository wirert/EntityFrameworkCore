﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=.;Database=MusicHub;TrustServerCertificate=True;User Id=sa;Password=AsDf23SQLServer;Encrypt=False";
    }
}
